package com.virtusa.css.dao;
import com.virtusa.css.dtoo.Product;
public interface IProduct {
	public boolean addUser(Product l);
	public boolean checkdelivery(Product l); 
}
